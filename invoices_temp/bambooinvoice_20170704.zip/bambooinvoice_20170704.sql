#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(39) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gtucd0a9s4plrfa297deh31h7iiu0tai', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499136090', '__ci_last_regenerate|i:1499136072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g5bjfemvjdqce91t5bjb6ng2dq63n839', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499137188', '__ci_last_regenerate|i:1499136986;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9bcshlbbetuf5hrpam2n9crqur8ui76', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499137912', '__ci_last_regenerate|i:1499137742;user_id|s:1:\"1\";logged_in|b:1;message|s:37:\"Invoice payment successfully entered.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l4kv3q2kufdn8a5r87gbi8p46jgsj06a', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499180261', '__ci_last_regenerate|i:1499180171;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sm20s9b91kpeo83nlddf85e63khe0oje', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499198585', '__ci_last_regenerate|i:1499198530;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44vgdm3vn4qbr9d76tr2ifd44lrgmllb', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499199624', '__ci_last_regenerate|i:1499199326;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('udrnc8r2emgrqjn4nta0hs9ivs4hclr9', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499199817', '__ci_last_regenerate|i:1499199632;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mchtd8pr19mrfjnpcknud87q41lgqcik', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499200249', '__ci_last_regenerate|i:1499200165;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56f02ev9j5njjd0rujhcji54835a56d6', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499200570', '__ci_last_regenerate|i:1499200550;user_id|s:1:\"1\";logged_in|b:1;message|s:37:\"Invoice payment successfully entered.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f4jtn0k5fo5b23tsiag9s4eht9hccnnk', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499204573', '__ci_last_regenerate|i:1499204562;user_id|s:1:\"1\";logged_in|b:1;');


#
# TABLE STRUCTURE FOR: clientcontacts
#

DROP TABLE IF EXISTS `clientcontacts`;

CREATE TABLE `clientcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `email` varchar(127) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('1', '0', NULL, NULL, NULL, 'greg.wojtak@gmail.com', NULL, 'oEsg7usAcHTmRidhc19scxLGc7wZEPfs804/o+2POx213v6SvSvZlzDbz8Usm05/k8NCIsFf3ov3YLFJrqoEcg==', '1', NULL, '1381848093', '');
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('2', '1', 'Jason', 'Wieland', '0', 'jason@ilnp.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('3', '2', 'Glenn', 'Kirbo', '0', 'glenn@maplarge.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('5', '3', 'Paula', 'Patrice', '', 'pp@ppweb.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('6', '4', 'Nathan', 'Tyler', '', 'nathan@tylerdigital.com', '', NULL, '0', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext,
  `tax_code` varchar(75) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('1', 'ILNP Cosmetics, Inc.', '', '', '', '', '', '', 'ilnp.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('2', 'Map Large, Inc.', '', '', '', '', '', '', 'maplarge.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('3', 'PPWeb Technologies', '', '', '', '', '', '', 'http://www.ppweb.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('4', 'Tyler Digital', '', '', '', '', '', '', 'http://tylerdigital.com', '0', NULL, '');


#
# TABLE STRUCTURE FOR: invoice_histories
#

DROP TABLE IF EXISTS `invoice_histories`;

CREATE TABLE `invoice_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `clientcontacts_id` varchar(255) DEFAULT NULL,
  `date_sent` date DEFAULT NULL,
  `contact_type` int(1) DEFAULT NULL,
  `email_body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('1', '1', 'a:1:{i:0;s:13:\"Jason Weiland\";}', '2016-02-14', '1', 'Hi Jason,\n\nI\'ve attached an invoice for the time I spent on verifying and repairing the MySQL replication.  As always, thanks for contacting me and allowing me to work with you!\n\nGreg Wojtak');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('2', '2', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-02-21', '1', 'Hi Glenn,\n\nCould you let me know if this format for the invoice works for you or if I need to change it?\n\nThanks!\n\nGreg');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('3', '3', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-02-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('4', '4', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2016-03-06', '1', 'Thanks Jason!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('5', '5', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-03-06', '1', 'Thanks Glenn!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('6', '6', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-03-13', '1', 'Thanks Glenn!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('7', '7', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-03-20', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('8', '10', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2016-05-11', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('9', '11', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2016-07-29', '1', 'Thanks Jason!');


#
# TABLE STRUCTURE FOR: invoice_items
#

DROP TABLE IF EXISTS `invoice_items`;

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `amount` decimal(11,2) DEFAULT '0.00',
  `quantity` decimal(7,2) DEFAULT '1.00',
  `work_description` mediumtext,
  `taxable` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('1', '1', '30.00', '1.00', 'MySQL replication verification and re-sync after database switchover', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('2', '2', '55.00', '2.50', 'Hours for week of 2/14 - 2/20\n - Rework instructions on http://install.maplarge.com/welcom.html\n - Figure out dependency on RHEL 6 systems on libxerces and why it is breaking', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('3', '3', '55.00', '11.25', 'Monday 2/22 - Saturday 2/27\nBuild environment deploy set up\nChanges and repackaging for apache keep alive', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('4', '4', '50.00', '5.50', '5.5 hours for:\n\nOS updates for 6 VM\'s (web, db, monitor, slave db)\nRepair MySQL replication for ilnp after db move\n', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('5', '5', '55.00', '2.75', 'Work for week of 2/29 - 3/5\nComplete build environment set up script', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('6', '6', '55.00', '3.00', 'Fix bugs and feature adds in maplarge build environment setup script', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('7', '7', '55.00', '1.00', 'Adjustments and fixes to build environment set up script.', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('8', '8', '55.00', '11.00', 'RPM Changes for API Server packaging', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('9', '9', '55.00', '4.75', 'Maplarge-api-server RPM modifications for BAE', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('10', '10', '50.00', '1.00', 'Clean up mysql /data filesystem\nVerify replication\nClean up root filesystem fix /nas mount\nTweak nagios alerting thresholds', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('11', '11', '35.00', '1.00', 'Correction of false alerts from watcher script.', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('12', '12', '85.00', '1.00', '22 June - Initial consultation, check over installation', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('13', '12', '50.00', '5.00', '22 June - further configuration, apache and php module additions, backups', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('14', '12', '50.00', '3.00', '25 June - clean up for a few items from Jun 22, fix broken access (ftp and ssh), DNS configuration help', '0');


#
# TABLE STRUCTURE FOR: invoice_payments
#

DROP TABLE IF EXISTS `invoice_payments`;

CREATE TABLE `invoice_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `amount_paid` float(7,2) DEFAULT NULL,
  `payment_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('1', '1', '2016-02-18', '30.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('2', '4', '2016-03-08', '275.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('3', '3', '2016-03-26', '518.75', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('4', '5', '2016-03-28', '151.25', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('5', '6', '2016-04-05', '165.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('6', '7', '2016-04-11', '55.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('7', '8', '2016-04-14', '605.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('8', '9', '2016-04-14', '261.25', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('9', '2', '2016-04-25', '137.50', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('10', '3', '2016-04-25', '100.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('11', '10', '2016-07-29', '50.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('12', '11', '2017-07-03', '35.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('13', '12', '2017-07-04', '485.00', '0');


#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS `invoices`;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `dateIssued` date DEFAULT NULL,
  `payment_term` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` decimal(6,3) DEFAULT NULL,
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` decimal(6,3) DEFAULT NULL,
  `invoice_note` text,
  `days_payment_due` int(3) unsigned DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;

INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('1', '1', '57', '2016-02-14', NULL, '0', '0.000', '0', '0.000', 'Please send payment to greg.wojtak@gmail.com via PayPal', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('2', '2', '58', '2016-02-21', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('3', '2', '59', '2016-02-28', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('4', '1', '60', '2016-03-06', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('5', '2', '61', '2016-03-06', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('6', '2', '67', '2016-03-13', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('7', '2', '73', '2016-03-20', NULL, '0', '0.000', '0', '0.000', 'Thank you!', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('8', '2', '1', '2016-01-10', NULL, '0', '0.000', '0', '0.000', 'Imported from Word document invoice #001', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('9', '2', '2', '2016-01-17', NULL, '0', '0.000', '0', '0.000', 'Imported from Word document invoice #002', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('10', '1', '75', '2016-05-11', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('11', '1', '79', '2016-07-29', NULL, '0', '0.000', '0', '0.000', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('12', '3', '107', '2017-06-28', NULL, NULL, '0.000', NULL, '0.000', '', '30');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `primary_contact` varchar(75) DEFAULT NULL,
  `primary_contact_email` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `logo_pdf` varchar(50) DEFAULT NULL,
  `invoice_note_default` varchar(255) DEFAULT NULL,
  `currency_type` varchar(20) DEFAULT NULL,
  `currency_symbol` varchar(9) DEFAULT '$',
  `tax_code` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` float(6,3) DEFAULT '0.000',
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` float(6,3) DEFAULT '0.000',
  `save_invoices` char(1) DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) DEFAULT 'n',
  `display_branding` char(1) DEFAULT 'y',
  `bambooinvoice_version` varchar(9) DEFAULT NULL,
  `new_version_autocheck` char(1) DEFAULT 'n',
  `logo_realpath` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `settings` (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES ('1', 'Greg Wojtak', '', '', 'Brentwood', 'TN', '', '37027', '', 'greg.wojtak@gmail.com', 'greg.wojtak@gmail.com', 'blank.gif', 'blank.gif', '', '', '$', '', '', '0.000', '', '0.000', 'y', '30', 'n', NULL, '0.8.9', NULL, 'n');


