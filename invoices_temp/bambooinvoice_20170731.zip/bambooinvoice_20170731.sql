#
# TABLE STRUCTURE FOR: ci_sessions
#

DROP TABLE IF EXISTS `ci_sessions`;

CREATE TABLE `ci_sessions` (
  `id` varchar(128) NOT NULL,
  `ip_address` varchar(39) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT '0',
  `data` blob NOT NULL,
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gtucd0a9s4plrfa297deh31h7iiu0tai', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499136090', '__ci_last_regenerate|i:1499136072;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g5bjfemvjdqce91t5bjb6ng2dq63n839', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499137188', '__ci_last_regenerate|i:1499136986;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('p9bcshlbbetuf5hrpam2n9crqur8ui76', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499137912', '__ci_last_regenerate|i:1499137742;user_id|s:1:\"1\";logged_in|b:1;message|s:37:\"Invoice payment successfully entered.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l4kv3q2kufdn8a5r87gbi8p46jgsj06a', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499180261', '__ci_last_regenerate|i:1499180171;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sm20s9b91kpeo83nlddf85e63khe0oje', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499198585', '__ci_last_regenerate|i:1499198530;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('44vgdm3vn4qbr9d76tr2ifd44lrgmllb', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499199624', '__ci_last_regenerate|i:1499199326;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('udrnc8r2emgrqjn4nta0hs9ivs4hclr9', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499199817', '__ci_last_regenerate|i:1499199632;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mchtd8pr19mrfjnpcknud87q41lgqcik', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499200249', '__ci_last_regenerate|i:1499200165;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('56f02ev9j5njjd0rujhcji54835a56d6', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499200570', '__ci_last_regenerate|i:1499200550;user_id|s:1:\"1\";logged_in|b:1;message|s:37:\"Invoice payment successfully entered.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f4jtn0k5fo5b23tsiag9s4eht9hccnnk', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499204586', '__ci_last_regenerate|i:1499204562;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('5s4tgqnqeaqv7du3oigm9ltot09vnm78', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1499213888', '__ci_last_regenerate|i:1499213874;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ndji200mej0qchfo6sqgj7f2rja2lc27', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500516472', '__ci_last_regenerate|i:1500516236;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4u9s24dqg4a5b04o7ij2a6as8e6q6sjr', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500861519', '__ci_last_regenerate|i:1500861513;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0vk5jjbeoc18uo8l090mmubgntoofto8', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500862139', '__ci_last_regenerate|i:1500861840;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('f0q64o91m6hiukcsluksnfuf6u8sjjej', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500862217', '__ci_last_regenerate|i:1500862185;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6pv3fcj27q8gb9vmpg7cmlo8a3krko3', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500862697', '__ci_last_regenerate|i:1500862670;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7sbba4j5e12a6euejgjijmuiku1vub9n', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500949084', '__ci_last_regenerate|i:1500949063;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('67qladir0g49q54c50ev2cblfoohkfhc', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1500952224', '__ci_last_regenerate|i:1500952204;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o41r2v2ut1or27hlqokjiida384d1nn8', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501277294', '__ci_last_regenerate|i:1501277092;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gieej0ovrtfllf26iktn5bevq5np6ncm', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501279523', '__ci_last_regenerate|i:1501279270;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('7nbe2lpl07vc245pe7ft11p813m9pebv', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501279837', '__ci_last_regenerate|i:1501279728;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0e7l0j9ut7a6cdkot0oqhsqiic7djf6j', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501295010', '__ci_last_regenerate|i:1501294985;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2is71su69f54c36b717piu23qc08rcag', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501359548', '__ci_last_regenerate|i:1501359533;user_id|s:1:\"1\";logged_in|b:1;clientName|N;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('vt1u8vq49jjmbdmhdpprmdds8g9jo11g', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501372564', '');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hc7cm93krfjilu2ajilhmugcieg0e1v2', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501372564', '');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('fsojjs825pt42rgimd5s0a0dgtikr89u', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501372715', '__ci_last_regenerate|i:1501372638;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('n3mvir7f3m5h62c55qpsmbca43rdialq', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501378817', '__ci_last_regenerate|i:1501378796;user_id|s:1:\"1\";logged_in|b:1;status|s:32:\"Settings successfully modified. \";__ci_vars|a:1:{s:6:\"status\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('etm702routt9ed1b72o90jm6bd7bqfk1', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501380709', '__ci_last_regenerate|i:1501380502;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qohjtn7g9kaj162jcol2bcsgndjkn5q0', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501452194', '__ci_last_regenerate|i:1501452169;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('i6gv6ok8je562juslau7buub990luppk', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501554236', '__ci_last_regenerate|i:1501554005;user_id|s:1:\"1\";logged_in|b:1;');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('hcrapadngut8vb52dj85n3u198jmdlai', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501554449', '__ci_last_regenerate|i:1501554312;user_id|s:1:\"1\";logged_in|b:1;message|s:80:\"Invoice successfully emailed. You can review this invoice&rsquo;s history below.\";__ci_vars|a:1:{s:7:\"message\";s:3:\"old\";}');
INSERT INTO `ci_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('l5hf9ocin3eplaue3vj6cqupfk9c00ui', '2601:484:c201:e20:1436:cfa2:c21b:6acd', '1501554995', '__ci_last_regenerate|i:1501554991;user_id|s:1:\"1\";logged_in|b:1;');


#
# TABLE STRUCTURE FOR: clientcontacts
#

DROP TABLE IF EXISTS `clientcontacts`;

CREATE TABLE `clientcontacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `first_name` varchar(25) DEFAULT NULL,
  `last_name` varchar(25) DEFAULT NULL,
  `title` varchar(75) DEFAULT NULL,
  `email` varchar(127) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `password` varchar(100) DEFAULT NULL,
  `access_level` tinyint(1) DEFAULT '0',
  `supervisor` int(11) DEFAULT NULL,
  `last_login` int(11) DEFAULT NULL,
  `password_reset` varchar(12) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('1', '0', NULL, NULL, NULL, 'greg.wojtak@gmail.com', NULL, '1asKDxevxw9KjC+DIlkoUJ7DoUqDFPd7QwzLh2ZPMcFEHGJB7LeSyagkBLh31zcTRwg+5OBMnvr1TOXAfYOXrQ==', '1', NULL, '1381848093', '');
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('2', '1', 'Jason', 'Wieland', '0', 'jason@ilnp.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('3', '2', 'Glenn', 'Kirbo', '0', 'glenn@maplarge.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('5', '3', 'Paula', 'Patrice', '', 'pp@ppweb.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('6', '4', 'Nathan', 'Tyler', '', 'nathan@tylerdigital.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('7', '5', 'Andrew', 'Scudder', '', '1andrewscudder@gmail.com', '', NULL, '0', NULL, NULL, NULL);
INSERT INTO `clientcontacts` (`id`, `client_id`, `first_name`, `last_name`, `title`, `email`, `phone`, `password`, `access_level`, `supervisor`, `last_login`, `password_reset`) VALUES ('8', '6', 'Greg', 'Wojtak', '', 'greg.wojtak@gmail.com', '', NULL, '0', NULL, NULL, NULL);


#
# TABLE STRUCTURE FOR: clients
#

DROP TABLE IF EXISTS `clients`;

CREATE TABLE `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `tax_status` int(1) DEFAULT '1',
  `client_notes` mediumtext,
  `tax_code` varchar(75) DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('1', 'ILNP Cosmetics, Inc.', '', '', '', '', '', '', 'ilnp.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('2', 'Map Large, Inc.', '', '', '', '', '', '', 'maplarge.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('3', 'PPWeb Technologies', '', '', '', '', '', '', 'http://www.ppweb.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('4', 'Tyler Digital', '', '', '', '', '', '', 'http://tylerdigital.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('5', 'CodeHelper', '', '', '', '', '', '', 'http://codehelper.com', '0', NULL, '');
INSERT INTO `clients` (`id`, `name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `tax_status`, `client_notes`, `tax_code`) VALUES ('6', 'Testing, Inc.', '123 Main St', '', 'Brentwood', 'TN', '', '37027', '', '0', NULL, '');


#
# TABLE STRUCTURE FOR: invoice_histories
#

DROP TABLE IF EXISTS `invoice_histories`;

CREATE TABLE `invoice_histories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `clientcontacts_id` varchar(255) DEFAULT NULL,
  `date_sent` date DEFAULT NULL,
  `contact_type` int(1) DEFAULT NULL,
  `email_body` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8;

INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('1', '1', 'a:1:{i:0;s:13:\"Jason Weiland\";}', '2016-02-14', '1', 'Hi Jason,\n\nI\'ve attached an invoice for the time I spent on verifying and repairing the MySQL replication.  As always, thanks for contacting me and allowing me to work with you!\n\nGreg Wojtak');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('2', '2', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-02-21', '1', 'Hi Glenn,\n\nCould you let me know if this format for the invoice works for you or if I need to change it?\n\nThanks!\n\nGreg');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('3', '3', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-02-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('4', '4', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2016-03-06', '1', 'Thanks Jason!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('5', '5', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-03-06', '1', 'Thanks Glenn!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('6', '6', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-03-13', '1', 'Thanks Glenn!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('7', '7', 'a:1:{i:0;s:11:\"Glenn Kirbo\";}', '2016-03-20', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('8', '10', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2016-05-11', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('9', '11', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2016-07-29', '1', 'Thanks Jason!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('10', '13', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2017-07-19', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('11', '14', 'a:1:{i:0;s:13:\"Paula Patrice\";}', '2017-07-19', '1', 'For work done up to July 18');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('12', '15', 'a:1:{i:0;s:14:\"Andrew Scudder\";}', '2017-07-23', '1', 'Thanks Andrew, I appreciate it!');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('13', '16', 'a:1:{i:0;s:11:\"Greg Wojtak\";}', '2017-07-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('14', '16', 'a:1:{i:0;s:11:\"Greg Wojtak\";}', '2017-07-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('15', '16', 'a:1:{i:0;s:11:\"Greg Wojtak\";}', '2017-07-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('16', '16', 'a:1:{i:0;s:11:\"Greg Wojtak\";}', '2017-07-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('17', '13', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2017-07-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('18', '15', 'a:1:{i:0;s:14:\"Andrew Scudder\";}', '2017-07-28', '1', '');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('19', '13', 'a:1:{i:0;s:13:\"Jason Wieland\";}', '2017-07-29', '1', 'Hi Jason,\r\n\r\nI was having problems with my mail server (again), so I\'m not sure if this got to you or not.  I apologize if you are getting this multiple times!\r\n\r\nGreg');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('20', '17', 'a:1:{i:0;s:14:\"Andrew Scudder\";}', '2017-07-29', '1', 'Hey Andrew, this is for the ansible work up until now for the base image.');
INSERT INTO `invoice_histories` (`id`, `invoice_id`, `clientcontacts_id`, `date_sent`, `contact_type`, `email_body`) VALUES ('21', '18', 'a:1:{i:0;s:13:\"Paula Patrice\";}', '2017-07-31', '1', '');


#
# TABLE STRUCTURE FOR: invoice_items
#

DROP TABLE IF EXISTS `invoice_items`;

CREATE TABLE `invoice_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT '0',
  `amount` decimal(11,2) DEFAULT '0.00',
  `quantity` decimal(7,2) DEFAULT '1.00',
  `work_description` mediumtext,
  `taxable` int(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('1', '1', '30.00', '1.00', 'MySQL replication verification and re-sync after database switchover', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('2', '2', '55.00', '2.50', 'Hours for week of 2/14 - 2/20\n - Rework instructions on http://install.maplarge.com/welcom.html\n - Figure out dependency on RHEL 6 systems on libxerces and why it is breaking', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('3', '3', '55.00', '11.25', 'Monday 2/22 - Saturday 2/27\nBuild environment deploy set up\nChanges and repackaging for apache keep alive', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('4', '4', '50.00', '5.50', '5.5 hours for:\n\nOS updates for 6 VM\'s (web, db, monitor, slave db)\nRepair MySQL replication for ilnp after db move\n', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('5', '5', '55.00', '2.75', 'Work for week of 2/29 - 3/5\nComplete build environment set up script', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('6', '6', '55.00', '3.00', 'Fix bugs and feature adds in maplarge build environment setup script', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('7', '7', '55.00', '1.00', 'Adjustments and fixes to build environment set up script.', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('8', '8', '55.00', '11.00', 'RPM Changes for API Server packaging', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('9', '9', '55.00', '4.75', 'Maplarge-api-server RPM modifications for BAE', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('10', '10', '50.00', '1.00', 'Clean up mysql /data filesystem\nVerify replication\nClean up root filesystem fix /nas mount\nTweak nagios alerting thresholds', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('11', '11', '35.00', '1.00', 'Correction of false alerts from watcher script.', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('12', '12', '85.00', '1.00', '22 June - Initial consultation, check over installation', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('13', '12', '50.00', '5.00', '22 June - further configuration, apache and php module additions, backups', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('14', '12', '50.00', '3.00', '25 June - clean up for a few items from Jun 22, fix broken access (ftp and ssh), DNS configuration help', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('15', '13', '30.00', '1.00', 'troubleshooting server lockup', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('16', '14', '50.00', '1.00', 'miscellaneous finishing-up work on mercury-security server', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('17', '15', '50.00', '1.50', '- MySQL troubleshooting\r\n- Correcting issue with apache and php-fpm and raising file descriptor limits', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('18', '16', '55.00', '23.00', '', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('19', '17', '50.00', '6.50', 'creation, testing of ansible roles and playbooks for core image updating and management\r\ntroubleshooting cloudflare load balancers', '0');
INSERT INTO `invoice_items` (`id`, `invoice_id`, `amount`, `quantity`, `work_description`, `taxable`) VALUES ('20', '18', '50.00', '1.00', 'Upgrade EasyApache3 -> 4, export and import configuration for EA4, check backups and accounts and other misc settings in new VPS.', '0');


#
# TABLE STRUCTURE FOR: invoice_payments
#

DROP TABLE IF EXISTS `invoice_payments`;

CREATE TABLE `invoice_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `invoice_id` int(11) DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `amount_paid` float(7,2) DEFAULT NULL,
  `payment_note` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('1', '1', '2016-02-18', '30.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('2', '4', '2016-03-08', '275.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('3', '3', '2016-03-26', '518.75', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('4', '5', '2016-03-28', '151.25', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('5', '6', '2016-04-05', '165.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('6', '7', '2016-04-11', '55.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('7', '8', '2016-04-14', '605.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('8', '9', '2016-04-14', '261.25', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('9', '2', '2016-04-25', '137.50', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('10', '3', '2016-04-25', '100.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('11', '10', '2016-07-29', '50.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('12', '11', '2017-07-03', '35.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('13', '12', '2017-07-04', '485.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('14', '14', '2017-07-19', '50.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('15', '16', '2017-07-28', '1265.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('16', '15', '2017-07-28', '75.00', '0');
INSERT INTO `invoice_payments` (`id`, `invoice_id`, `date_paid`, `amount_paid`, `payment_note`) VALUES ('17', '13', '2017-07-30', '30.00', '0');


#
# TABLE STRUCTURE FOR: invoices
#

DROP TABLE IF EXISTS `invoices`;

CREATE TABLE `invoices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) DEFAULT NULL,
  `invoice_number` varchar(255) DEFAULT NULL,
  `dateIssued` date DEFAULT NULL,
  `payment_term` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` decimal(6,2) DEFAULT '0.00',
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` decimal(6,2) DEFAULT '0.00',
  `invoice_note` text,
  `days_payment_due` int(3) unsigned DEFAULT '30',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('1', '1', '57', '2016-02-14', NULL, '0', '0.00', '0', '0.00', 'Please send payment to greg.wojtak@gmail.com via PayPal', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('2', '2', '58', '2016-02-21', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('3', '2', '59', '2016-02-28', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('4', '1', '60', '2016-03-06', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('5', '2', '61', '2016-03-06', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('6', '2', '67', '2016-03-13', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('7', '2', '73', '2016-03-20', NULL, '0', '0.00', '0', '0.00', 'Thank you!', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('8', '2', '1', '2016-01-10', NULL, '0', '0.00', '0', '0.00', 'Imported from Word document invoice #001', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('9', '2', '2', '2016-01-17', NULL, '0', '0.00', '0', '0.00', 'Imported from Word document invoice #002', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('10', '1', '75', '2016-05-11', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('11', '1', '79', '2016-07-29', NULL, '0', '0.00', '0', '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('12', '3', '107', '2017-06-28', NULL, NULL, '0.00', NULL, '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('13', '1', '108', '2017-07-19', NULL, NULL, '0.00', NULL, '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('14', '3', '109', '2017-07-19', NULL, NULL, '0.00', NULL, '0.00', '', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('15', '5', '110', '2017-07-23', NULL, NULL, '0.00', NULL, '0.00', 'Please remit payment to greg.wojtak@gmail.com via PayPal, and thank you!', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('16', '6', '111', '2017-07-28', NULL, NULL, '0.00', NULL, '0.00', 'testing', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('17', '5', '115', '2017-07-29', NULL, NULL, '0.00', NULL, '0.00', 'Please remit payment via PayPal to greg.wojtak@gmail.com.  Thank you!', '30');
INSERT INTO `invoices` (`id`, `client_id`, `invoice_number`, `dateIssued`, `payment_term`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `invoice_note`, `days_payment_due`) VALUES ('18', '3', '116', '2017-07-28', NULL, NULL, '0.00', NULL, '0.00', '', '30');


#
# TABLE STRUCTURE FOR: settings
#

DROP TABLE IF EXISTS `settings`;

CREATE TABLE `settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(75) DEFAULT NULL,
  `address1` varchar(100) DEFAULT NULL,
  `address2` varchar(100) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `province` varchar(25) DEFAULT NULL,
  `country` varchar(25) DEFAULT NULL,
  `postal_code` varchar(10) DEFAULT NULL,
  `website` varchar(150) DEFAULT NULL,
  `primary_contact` varchar(75) DEFAULT NULL,
  `primary_contact_email` varchar(50) DEFAULT NULL,
  `logo` varchar(50) DEFAULT NULL,
  `logo_pdf` varchar(50) DEFAULT NULL,
  `invoice_note_default` varchar(255) DEFAULT NULL,
  `currency_type` varchar(20) DEFAULT NULL,
  `currency_symbol` varchar(9) DEFAULT '$',
  `tax_code` varchar(50) DEFAULT NULL,
  `tax1_desc` varchar(50) DEFAULT NULL,
  `tax1_rate` decimal(6,2) DEFAULT '0.00',
  `tax2_desc` varchar(50) DEFAULT NULL,
  `tax2_rate` decimal(6,2) DEFAULT '0.00',
  `save_invoices` char(1) DEFAULT 'n',
  `days_payment_due` int(3) unsigned DEFAULT '30',
  `demo_flag` char(1) DEFAULT 'n',
  `display_branding` char(1) DEFAULT 'y',
  `bambooinvoice_version` varchar(9) DEFAULT NULL,
  `new_version_autocheck` char(1) DEFAULT 'n',
  `logo_realpath` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `settings` (`id`, `company_name`, `address1`, `address2`, `city`, `province`, `country`, `postal_code`, `website`, `primary_contact`, `primary_contact_email`, `logo`, `logo_pdf`, `invoice_note_default`, `currency_type`, `currency_symbol`, `tax_code`, `tax1_desc`, `tax1_rate`, `tax2_desc`, `tax2_rate`, `save_invoices`, `days_payment_due`, `demo_flag`, `display_branding`, `bambooinvoice_version`, `new_version_autocheck`, `logo_realpath`) VALUES ('1', 'Greg Wojtak', '', '', 'Brentwood', 'TN', '', '37027', '', 'greg.wojtak@gmail.com', 'greg.wojtak@gmail.com', 'blank.gif', 'blank.gif', '', '', '$', '', '', '0.00', '', '0.00', 'y', '30', 'n', NULL, '0.8.9', NULL, 'n');


